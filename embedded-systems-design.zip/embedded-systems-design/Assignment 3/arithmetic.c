// Samantha Nickole Salas - xso947

#include <stdio.h> 
#include "intops/int_arithmetic.h"
//#include "doubleops/double_arithmetic.h"

int main() 
{
    float a = 30;
    float b = 6;

    float result1 = addint(a, b);
    float result2 = subtractint(a, b);
    float result3 = multiplyint(a, b);
    float result4 = divideint(a, b);

    printf("The sum of %.02lf and %.02lf is %.02lf\n", a, b, result1);
    printf("The difference of %.02lf and %.02lf is %.02lf\n", a, b, result2);
    printf("The product of %.02lf and %.02lf is %.02lf\n", a, b, result3);
    printf("The quotient of %.02lf and %.02lf is %.02lf\n", a, b, result4);
    return 0;
}