#include "int_arithmetic.h"

int subtractint(int a, int b)
{
    return a - b;
}