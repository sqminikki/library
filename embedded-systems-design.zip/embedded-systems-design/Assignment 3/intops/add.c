#include "int_arithmetic.h"

int addint(int a, int b)
{
    return a + b;
}