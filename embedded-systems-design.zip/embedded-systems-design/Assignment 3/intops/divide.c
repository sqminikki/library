#include "int_arithmetic.h"

int divideint(int a, int b)
{
    return a / b;
}