
#ifndef INTARITHMETIC_H
#define INTARITHMETIC_H

#ifdef __cplusplus
extern "C"
{
#endif

    int addint(int a, int b);
    int subtractint(int a, int b);
    int multiplyint(int a, int b);
    int divideint(int a, int b);

#ifdef __cplusplus
}
#endif

#endif