#include "int_arithmetic.h"

int multiplyint(int a, int b)
{
    return a * b;
}