#include "double_arithmetic.h"

double multiply_double(double a, double b)
{
    return a * b;
}