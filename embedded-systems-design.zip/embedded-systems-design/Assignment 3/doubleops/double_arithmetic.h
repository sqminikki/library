
#ifndef DOUBLEARITHMETIC_H
#define DOUBLEARITHMETIC_H

#ifdef __cplusplus
extern "C"
{
#endif

    double addint(double a, double b);
    double subtractint(double a, double b);
    double multiplyint(double a, double b);
    double divideint(double a, double b);

#ifdef __cplusplus
}
#endif

#endif