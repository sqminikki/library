#include "double_arithmetic.h"

double add_double(double a, double b)
{
    return a + b;
}