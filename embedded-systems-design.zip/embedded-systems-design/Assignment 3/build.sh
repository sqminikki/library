#!/bin/bash

set -x # Print commands and their arguments as they are executed
set -e # Exit immediately if a command exits with a non-zero status

# Compile libarithmetic for int operations

cd intops

gcc -fPIC -c add.c -o add.o
gcc -fPIC -c subtract.c -o subtract.o
gcc -fPIC -c multiply.c -o multiply.o
gcc -fPIC -c divide.c -o divide.o
gcc -shared -o libarithmetic.so add.o subtract.o multiply.o divide.o

# Clean up artifacts

rm add.o
rm subtract.o
rm multiply.o
rm divide.o

cd ..

# Compile libcpparithmetic for double operations

cd doubleops

g++ -fPIC -c add.cpp -o add.o
g++ -fPIC -c subtract.cpp -o subtract.o
g++ -fPIC -c multiply.cpp -o multiply.o
g++ -fPIC -c divide.cpp -o divide.o
g++ -shared -o libcpparithmetic.so add.o subtract.o multiply.o divide.o

# Clean up artifacts

rm add.o
rm subtract.o
rm multiply.o
rm divide.o

cd ..

# Move libraries into working directory

mv ./intops/libarithmetic.so ./libarithmetic.so
mv ./doubleops/libcpparithmetic.so ./libcpparithmetic.so

# Compile example

gcc -o example arithmetic.c -L. -l:libarithmetic.so -l:libcpparithmetic.so
echo Build complete.

# Run example

echo Running ./example
export LD_LIBRARY_PATH=$PWD
./example

# Clean up artifacts

rm example
rm libarithmetic.so
rm libcpparithmetic.so