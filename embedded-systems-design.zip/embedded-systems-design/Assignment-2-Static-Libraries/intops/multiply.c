#include "int_arithmetic.h"

int multiply(int a, int b);