#include "int_arithmetic.h"

int divide(int a, int b);